<!DOCTYPE html>
<html>
<head>
	<title> Challenge Lab</title>
  	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap.min.js"></script>
	<script type="text/javascript">
		 $(document).ready(function() {
		    $('#example').DataTable();
		 } );
	</script>
</head>
<body>
	<header>
		<nav class="navbar navbar-default">
			<div class="container-fluid">
			<div class="navbar-header">
				<h4 style="color:grey"> [IF635] Web Programming </h4>
			</div>
				<ul class="nav navbar-nav navbar-right">
				<li class="navbar-right active"><a href="#"> Employees</a></li>
				</ul>
			</div>
		</nav>
	</header> 

<div class="container">
<table id="example" class="table table-striped table-bordered" style="margin-left:auto;margin-right:auto" border="1" width="100%"> 
	<thead>
		<tr>
			<th> First Name </th>
			<th> Last Name </th>
			<th> Birth Date </th>
			<th> Title </th>
			<th> Address </th>
			<th> City </th>
			<th> Home Phone </th>
		</tr>
	</thead>
	<tbody>
			<?php 
				$host = "localhost";
				$username = "root";
				$dbname = "northwind";
				$password = "";

				$db = new mysqli($host, $username, $password, $dbname);

				$query = "SELECT * FROM employees LIMIT 12";
				$result = $db->query($query);

				while ($row = $result->fetch_assoc()) {
					echo "<tr>";
					echo "<td>" . $row['FirstName'] . "</td>";
					echo "<td>" . $row['LastName'] . "</td>";
					echo "<td>" . $row['BirthDate'] . "</td>";
					echo "<td>" . $row['Title'] . "</td>";
					echo "<td>" . $row['Address'] . "</td>";
					echo "<td>" . $row['City'] . "</td>";
					echo "<td>" . $row['HomePhone'] . "</td>";
					echo "</tr>";
				}

				mysqli_free_result($result);
				mysqli_close($db);
			 ?>
	</tbody>
	<tfoot>
		<tr>
			<th> First Name </th>
			<th> Last Name </th>
			<th> Birth Date </th>
			<th> Title </th>
			<th> Address </th>
			<th> City </th>
			<th> Home Phone </th>
		</tr>
	</tfoot>
</table>
</div>
</body>
</html>