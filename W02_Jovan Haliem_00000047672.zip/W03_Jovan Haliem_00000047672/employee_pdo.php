<!DOCTYPE html>
<html>
<head>
	<title> Tugas Pendahuluan</title>
  	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap.min.js"></script>
	<script type="text/javascript">
		 $(document).ready(function() {
		    $('#example').DataTable();
		 } );
	</script>
</head>
<body>
	<header>
		<nav class="navbar navbar-default">
			<div class="container-fluid">
				<div class="navbar-header">
					<h4 style="color:grey"> [IF635] Web Programming </h4>
				</div>
				<ul class="nav navbar-nav navbar-right">
					<li class="navbar-right active"><a href="#"> Products</a></li>
				</ul>
			</div>
			<?php 
				//Ini adalah lokasi dari mysql berada
				$host = "localhost";

				//Ini adalah user yang digunakan untuk login ke dalam module mysql / mariadb
				$username = "root";

				//Ini adalah nama database yang digunakan dalam praktikum ini 
				$dbname = "northwind";

				//Ini adalah password yang untuk autentikasi user
				$password = "";

				//Object database
				$conn = new PDO("mysql:host=$host;dbname=$dbname;", $username, $password);

				$query = "SELECT * FROM products LIMIT 12";
				$result = $conn->query($query);
			 ?>
		</nav>
	</header>
<div class="container">
<table id="example" class="table table-striped table-bordered" style="margin-left:auto;margin-right:auto" border="1" width="100%"> 
		<thead>
			<tr>
				<th> # </th>
				<th> Product Name </th>
				<th> Quantity Per Unit </th>
				<th> Price </th>
				<th> Stock </th>
			</tr>
		</thead>
		<tbody>
			<?php 
				foreach ($result as $row) {
					echo "<tr>";
					echo "<td>" . $row['ProductID'] . "</td>";
					echo "<td>" . $row['ProductName'] . "</td>";
					echo "<td>" . $row['QuantityPerUnit'] . "</td>";
					echo "<td>" . $row['UnitPrice'] . "</td>";
					echo "<td>" . $row['ReorderLevel'] . "</td>";
					echo "</tr>";
				}
			 ?>
		</tbody>
		<tfoot>
			<tr>
				<th> # </th>
				<th> Product Name </th>
				<th> Quantity Per Unit </th>
				<th> Price </th>
				<th> Stock </th>
			</tr>
		</tfoot>
	</table>
</body>
</html>