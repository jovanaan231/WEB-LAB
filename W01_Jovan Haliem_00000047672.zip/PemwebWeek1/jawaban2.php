<?php
    $arr2dim = array(
        "1" => array("#" => "1", "Product Name" => "Chai", "Quantity per Unit" => "10 boxes x 20 bags", "Price" => "18", "Stock" => "39"),
        "2" => array("#" => "2", "Product Name" => "Chang", "Quantity per Unit" => "24 - 12 oz bottles", "Price" => "19", "Stock" => "17"),
        "3" => array("#" => "3", "Product Name" => "Aniseed Syrup", "Quantity per Unit" => "12 - 550 ml bottles", "Price" => "10", "Stock" => "13"),
        "4" => array("#" => "4", "Product Name" => "Chef Anton's Cajun Seasoning", "Quantity per Unit" => "48 - 6 oz jars", "Price" => "22", "Stock" => "53"),
        "5" => array("#" => "5", "Product Name" => "Chef Anton's Gumbo Mix", "Quantity per Unit" => "36 boxes", "Price" => "21-35", "Stock" => "0"),
        "6" => array("#" => "6", "Product Name" => "Grandma's Boysenberry Spread", "Quantity per Unit" => "12 - 8 oz jars", "Price" => "25", "Stock" => "120"),
        "7" => array("#" => "7", "Product Name" => "Uncle Bob's Organic Dried Pears", "Quantity per Unit" => "12 - 1 lb pkgs", "Price" => "30", "Stock" => "15"),
        "8" => array("#" => "8", "Product Name" => "Northwoods Cranberry Sauce", "Quantity per Unit" => "12 - 12 oz jars", "Price" => "40", "Stock" => "6"),
        "9" => array("#" => "9", "Product Name" => "Mishi Kobe Niku", "Quantity per Unit" => "18 - 500 g pkgs", "Price" => "97", "Stock" => "29"),
        "10" => array("#" => "10", "Product Name" => "Ikura", "Quantity per Unit" => "12 - 200 ml jars", "Price" => "31", "Stock" => "31"),
        "11" => array("#" => "11", "Product Name" => "Queso Cabrales", "Quantity per Unit" => "1 kg pkg", "Price" => "21", "Stock" => "22"),
        "12" => array("#" => "12", "Product Name" => "Queso Manchego La Pastora", "Quantity per Unit" => "10 - 500 g pkgs", "Price" => "38", "Stock" => "86"),
    ); 
?>

<!DOCTYPE html>
<html lang="en"> 
<head>
 <title>IF330 Web</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap.min.js"></script>
</head>
<body>
    <nav class="navbar navbar-default">
    <div class="container-fluid">
    <div class="navbar-header">
    <a class="navbar-brand" href="#">[IF330] Web Programming </a>
    </div>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="#"><span class="glyphicon glyphicon-product"></span>Products</a></li>
    </ul>  
    </div>
    </nav>

<div class="container">       
<table id="example" class="table table-striped table-bordered" style="margin-left:auto;margin-right:auto" border="1" width="100%">    
    <thead>
        <tr>
            <th>#</th>
            <th>Product Name</th>
            <th>Quantity per Unit</th>
            <th>Price</th>
            <th>Stock</th>
        </tr>
     </thead>  
     <tfoot>
        <tr>
            <th>#</th>
            <th>Product Name</th>
            <th>Quantity per Unit</th>
            <th>Price</th>
            <th>Stock</th>
    </tr>
    </tfoot>    
    
    <?php  foreach ($arr2dim as $value) : ?>
        <tr>
            <td><?php echo $value["#"]."<br>"; ?></td>
            <td><?php echo $value["Product Name"]."<br>"; ?></td>
            <td><?php echo $value["Quantity per Unit"]."<br>"; ?></td>
            <td><?php echo $value["Price"]."<br>"; ?></td>
            <td><?php echo $value["Stock"]."<br>"; ?></td>
        </tr>  
    <?php endforeach; ?>
         
</table>
</div>

<script>
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>
</body>
</html>