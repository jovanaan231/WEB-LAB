<?php 
	$country = array(
		"India" => array(
			"Capital city" => "New Delhi",
			"Calling Code" => 91,
			"Currency Code" => "INR"
		),
		"Indonesia" => array(	
			"Capital city" => "Jakarta",
			"Calling Code" => 62,
			"Currency Code" => "IDR"
		),
		"Japan" => array(
			"Capital city" => "Tokyo",
			"Calling Code" => 81,
			"Currency Code" => "JPY"
		),
	);

	foreach($country as $key => $value){
		echo "<br><i><b>" . $value["Capital city"] . "</b></i>" . " " . "is capital city of" . " " . "<b>" . $key . ". </b> " . " <u> " .$key . "'s calling code is " . " " . $value["Calling Code"] . " " .  "and has" . " " . $value["Currency Code"] . " " .  "as currency code.</u>" ;
	}
 ?>