<div class="container text-center">
    <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%);">
        <h2>Maaf</h2>
        <h3>Halaman yang anda minta tidak dapat ditemukan!</h3>
    </div>
</div>