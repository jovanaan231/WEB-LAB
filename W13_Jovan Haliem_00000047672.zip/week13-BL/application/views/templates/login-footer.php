<script src="<?= base_url('assets/javascript/jquery-1.12.4.js'); ?>"></script>
<script src="<?= base_url('assets/javascript/bootstrap.min.js'); ?>"></script>

</body>

</html>