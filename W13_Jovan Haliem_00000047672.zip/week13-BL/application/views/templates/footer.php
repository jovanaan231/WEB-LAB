<script src="<?= base_url('assets/javascript/jquery-1.12.4.js'); ?>"></script>
<script src="<?= base_url('assets/javascript/bootstrap.min.js'); ?>"></script>
<script src="<?= base_url('assets/javascript/jquery.dataTables.min.js'); ?>"></script>
<script src="<?= base_url('assets/javascript/dataTables.bootstrap.min.js'); ?>"></script>


<script>
    $(function() {
        $('table').DataTable();
    });
</script>

</body>

</html>