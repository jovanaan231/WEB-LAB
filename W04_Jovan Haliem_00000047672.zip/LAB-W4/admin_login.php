<?php
include 'connect_db.php';

$email = $_POST['email'];
$password = $_POST['password'];
$queryEmailCheck = $db->prepare("SELECT * FROM users where email=:email");
$queryEmailCheck->bindParam(":email", $email);
$queryEmailCheck->execute();
$user = $queryEmailCheck->fetch();

if ($queryEmailCheck->rowCount() > 0) {
  $encrypted_password_salt = hash('sha256', $password . $user['salt']);

  if ($user['password'] === $encrypted_password_salt) {
    $_SESSION['id_user'] = $user['id_user'];
    header("location: $base_url");
  } else {
    $_SESSION['error_login_message'] = 'Email atau password salah';
    header("location: $base_url/challenge.php");
  }
} else {
  $_SESSION['error_login_message'] = 'Email atau password salah';
  header("location: $base_url/login.php");
}
