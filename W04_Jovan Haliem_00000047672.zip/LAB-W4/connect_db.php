<?php

$host = "localhost";

//Ini adalah user yang digunakan untuk login ke dalam module mysql / mariadb
$username = "root";

//Ini adalah nama database yang digunakan dalam praktikum ini 
$dbname = "students";

//Ini adalah password yang untuk autentikasi user
$password = "";

$base_url = 'https://localhost/phpdasar/~WEB%20LAB/LAB-W4/';

$db = new PDO("mysql:host=$host;dbname=$dbname;port=3306", $username, $password);