<?php
include 'connect_db.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap5.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js"></script>
</head>

<body>
  <br>
  <br>
  <br>
  <br>
  <div class="container d-flex justify-content-center">
      <div class="card-body">
        <h1>Sign In</h1>
        <hr/>
        <form id="form-login-submit" class="form-login" method="POST" action="<?= $base_url ?>admin_login.php" onsubmit="return handleSubmitLogin(this)">
          <div class="mb-3">
            <b><label for="exampleInputEmail1" class="form-label">Email</label></b>
            <input type="email" class="form-control" name="email" placeholder="Masukkan Email">
          </div>
          <div class="mb-3">
            <b><label for="exampleInputPassword1" class="form-label">Password</label></b>
            <input type="password" class="form-control" name="password" placeholder="Masukkan Password">
          </div>
          <?php if (isset($_SESSION['error_login_message'])) { ?>
            <div class="alert alert-danger py-1" role="alert">
              <?= $_SESSION['error_login_message'] ?>
            </div>
          <?php
            unset($_SESSION['error_login_message']);
          } ?>
          <button type="submit" class="btn btn-primary">Sign In</button>
        </form>
      </div>
  </div>

  <script>
    function handleSubmitLogin(form) {
      let input_email = $(form).find('input[name="email"]');
      let input_password = $(form).find('input[name="password"]');

      let ok = true;

      if (input_email.val() === '') {
        input_email.addClass('border-danger');
        ok = false;
      } else {
        input_email.removeClass('border-danger');
      }
      if (input_password.val() === '') {
        input_password.addClass('border-danger');
        ok = false;
      } else {
        input_password.removeClass('border-danger');
      }
      if (ok) {
        return true;
      } else {
        return false;
      }
    }
  </script>
</body>
</html>