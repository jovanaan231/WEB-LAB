<!DOCTYPE HTML>
<html>
    <body>
        Student ID   : <?php echo $obj->getID(); ?> <br/>
        Student Name : <?php echo $obj->getName(); ?>
    </body>
</html>