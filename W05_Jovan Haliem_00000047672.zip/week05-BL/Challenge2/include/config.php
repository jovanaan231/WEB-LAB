<?php
    $host = "localhost";
    $dbname = "studentweek3";
    $username = "root";
    $password = "";

    $db = new mysqli($host, $username, $password, $dbname);
?>

