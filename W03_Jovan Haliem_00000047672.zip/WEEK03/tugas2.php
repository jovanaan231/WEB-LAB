<?php
include 'connect_db.php';

$queryStudent = $db->prepare("SELECT * from student");
$queryStudent->execute();
$students = $queryStudent->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tugas</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.11.1/css/jquery.dataTables.min.css">
  <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
  <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
  <script src="https://cdn.datatables.net/1.11.1/js/jquery.dataTables.min.js"></script>
</head>

<body>
  <nav class="navbar navbar-default">
      <div class="container-fluid">
        <div class="navbar-header">
          <h4 style="color:grey"> [IF635] Web Programming </h4>
        </div>
        <ul class="nav navbar-nav navbar-right">
          <li class="navbar-right active"><a href="#"> Students</a></li>
        </ul>
      </div>
    </nav>
  <div class="container" align="right">
    <a href="add_student.php" class="btn btn-primary">Add Student</a>
    <table id="example" class="table table-striped" style="width:100%">
      <thead>
        <tr>
          <th>#</th>
          <th>StudentID</th>
          <th>FirstName</th>
          <th>LastName</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($students as $i => $student) { ?>
          <tr>
            <td><?= $i ?></td>
            <td><?= $student['StudentID'] ?></td>
            <td><?= $student['FirstName'] ?></td>
            <td><?= $student['LastName'] ?></td>
          </tr>
        <?php } ?>
      </tbody>
      <tfoot>
        <tr>
          <th>#</th>
          <th>StudentID</th>
          <th>FirstName</th>
          <th>LastName</th>
        </tr>
      </tfoot>
    </table>
  </div>

  <script>
    $(document).ready(function() {
      $('#example').DataTable({
        "order": [
          [0, 'asc']
        ]
      });
    });
  </script>
</body>

</html>