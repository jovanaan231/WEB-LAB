<?php
$student_id = $_GET['student_id'];

if ($student_id != null) {
    require 'connect_db.php';

    $query = "DELETE FROM student WHERE StudentID=?";
    $stmt = $conn->prepare($query);
    $stmt->execute([$student_id]);

    $conn = null;
} 

header('location: $base_url');
die();
