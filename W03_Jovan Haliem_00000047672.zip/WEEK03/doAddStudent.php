<?php
include 'connect_db.php';

$student_id = $_POST['student_id'];
$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];

$queryInsert = $db->prepare("INSERT into student(StudentID,FirstName,LastName) 
values (:student_id,:firstName,:lastName) ");

$queryInsert->bindParam(':student_id', $student_id);
$queryInsert->bindParam(':firstName', $first_name);
$queryInsert->bindParam(':lastName', $last_name);

$success = $queryInsert->execute();

if ($success) {
  header("location: $base_url");
}
