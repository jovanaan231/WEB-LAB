<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tambahkan Student</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.11.1/css/jquery.dataTables.min.css">
  <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
  <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
  <script src="https://cdn.datatables.net/1.11.1/js/jquery.dataTables.min.js"></script>
</head>

<body>
  <nav class="navbar navbar-default">
      <div class="container-fluid">
        <div class="navbar-header">
          <h4 style="color:grey"> [IF635] Web Programming </h4>
        </div>
        <ul class="nav navbar-nav navbar-right">
          <li class="navbar-right active"><a href="#"> Students</a></li>
        </ul>
      </div>
    </nav>
  <div class="container">
    <div class="card">
      <div class="card-body">
        <form method="POST" action="doAddStudent.php">
          <div class="mb-3">
            <label class="form-label">StudentID</label>
            <input type="text" class="form-control" name="student_id">
          </div>
          <div class="mb-3">
            <label class="form-label">FirstName</label>
            <input type="text" class="form-control" name="first_name">
          </div>
          <div class="mb-3">
            <label class="form-label">LastName</label>
            <input type="text" class="form-control" name="last_name">
          </div>
          <div class="mb-3">
            <label for="comment">Description</label>
            <textarea class="form-control" rows="5" id="description" name="description"></textarea>
          </div>
          <button type="submit" class="btn btn-primary">Submit</button>
          <input type="button" class="btn btn-light" value="Cancel" onclick="history.back(-1)" />
      </div>
    </div>
  </div>
</body>

</html>