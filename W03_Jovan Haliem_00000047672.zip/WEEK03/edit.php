<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Data</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap5.min.css">
  <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
  <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js"></script>
</head>

<body>
  <div class="container">
    <div class="card">
      <div class="card-body">
        <h2 align="center">Edit</h2>
          <div class="mb-3">
            <label class="form-label">StudentId</label>
            <input type="text" class="form-control" name="student_id">
          </div>
          <div class="mb-3">
            <label class="form-label">FirstName</label>
            <input type="text" class="form-control" name="first_name">
          </div>
          <div class="mb-3">
            <label class="form-label">LastName</label>
            <input type="text" class="form-control" name="last_name">
          </div>
          <div class="mb-3">
            <label for="comment">Description</label>
            <textarea class="form-control" rows="5" id="description" name="description"></textarea>
          </div>
          <button type="edit" class="btn btn-primary">Edit</button>
          <input type="button" class="btn btn-light" value="Cancel" onclick="history.back(-1)" />
        </form>
      </div>
    </div>
  </div>
</body>

</html>