<!DOCTYPE html>
<html>
<head>
    <?php
        echo $js;
        echo $css;
    ?>
    <title>Week 11</title>
</head>
<body>
    <?php echo $header; ?>
    <div class="container" style="margin-top: 10px;">
        <h1 style="display: inline;">Manage Products</h1>
        <h4 style="display: inline; color: gray;">&nbsp;Northwind Traders</h4>
        <a class="btn btn-primary" href="<?php echo site_url('Insert') ?>" role="button" style="float: right; display: inline;"><i class="fa fa-plus-circle"></i> Product</a>
        <hr>
        <table class="table table-striped table-bordered" id="my-table">
            <thead>
                <tr>
                    <th></th>
                    <th>Nama produk</th>
                    <th>QTY Per Unit</th>
                    <th>Price</th>
                    <th>Available Stock</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($product as $row){
                    $id_product = $row['id_product'];
                    $product_name = $row['product_name'];
                    $qty_per_unit = $row['qty_per_unit'];
                    $price = $row['price'];
                    $stock = $row['stock'];

                    echo "<tr>";
                    echo "<td>".$id_product."</td>";
                    echo "<td>".$product_name."</td>";
                    echo "<td>".$qty_per_unit."</td>";
                    echo "<td>".$price."</td>";
                    echo "<td>".$stock."</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
            <tfoot>
                <tr>
                    <th></th>
                    <th>Nama produk</th>
                    <th>QTY Per Unit</th>
                    <th>Price</th>
                    <th>Available Stock</th>
                </tr>
            </tfoot>
        </table>
    </div>
    <?php echo $footer; ?> 
</body>
</html>