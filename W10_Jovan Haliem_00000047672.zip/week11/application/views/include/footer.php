<div class="text-center footer">
    <p>Copyright 2021 - Jovan Haliem</p>
</div>

<style>
    .footer {
        position: fixed;
        left: 0;
        bottom: 0;
        width: 100%;
        background-color: grey;
        color: #EEEEEE;
        text-align: center;
    }
</style>

<script>
    $(document).ready(function() {
        $('#my-table').DataTable();
    });
</script>
