<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header" style="padding: 0 5%;">
            <a class="navbar-brand" href="<?php echo site_url('Home') ?>">Northwind Traders [IF635 UMN]</a>
        </div>
        <ul class="nav navbar-nav navbar-right" style="padding: 0 5%;">
            <li class="active"><a href="<?php echo site_url('Home') ?>">Product List</a></li>
        </ul>
    </div>
</nav>