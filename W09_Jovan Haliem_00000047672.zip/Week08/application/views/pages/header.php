<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header" style="padding: 0 5%;">
            <a class="navbar-brand" href="#">[IF635]Web Programming</a>
        </div>
        <ul class="nav navbar-nav navbar-right" style="padding: 0 5%;">
            <li class="active"><a href="#">Employees</a></li>
        </ul>
    </div>
</nav>