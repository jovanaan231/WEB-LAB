<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<hr>
<footer class="footer">
	<div class="container">
		<p class="text-muted">Northwind Trader - Education Purpose Only - 2015 </p>
	</div>
</footer>