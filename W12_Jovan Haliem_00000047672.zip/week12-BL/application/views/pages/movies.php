<!DOCTYPE html>
<html>
<head>
	<title> Code Igniter MVC </title>
	<?php echo $style; ?>
</head>
<body>
	<?php echo $navbar; ?>
	<div class="row" style="margin-top: 100px;">
		<div class="col-md-12"><?= $crud['output']; ?></div>
	</div>

	<?php echo $footer; ?>
	<?php echo $script; ?>
</body>
</html>